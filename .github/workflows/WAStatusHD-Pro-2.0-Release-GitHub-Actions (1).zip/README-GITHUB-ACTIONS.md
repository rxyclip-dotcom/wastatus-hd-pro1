# WAStatusHD-Pro — GitHub Actions

## Build APK langsung dari HP Android

1. Buat repository baru di GitHub.
2. Upload **isi ZIP ini** ke root repository (bukan file ZIP-nya).
3. Buka tab **Actions**.
4. Pilih workflow **Build Android APK**.
5. Tekan **Run workflow**.
6. Tunggu sampai status berubah menjadi selesai.
7. Buka hasil workflow tersebut.
8. Di bagian **Artifacts**, download `WAStatusHD-Pro-debug`.
9. Ekstrak file artifact dan install APK di HP.

Workflow ini **tidak membutuhkan Gradle Wrapper** karena GitHub Actions memasang Gradle 8.10.2 secara otomatis.

### Catatan
APK yang dihasilkan adalah **debug APK** untuk pengujian/install langsung. Untuk APK release yang ditandatangani, diperlukan konfigurasi signing key.
