# WA Status HD Pro 2.0 — Release APK

Paket ini sudah disiapkan untuk membuat **signed release APK** langsung melalui GitHub Actions, tanpa komputer.

## Dari HP Android

1. Buat repository baru di GitHub.
2. Upload **isi ZIP ini** ke root repository.
3. Buka tab **Actions**.
4. Pilih **Build WA Status HD Pro Release APK**.
5. Tekan **Run workflow**.
6. Setelah selesai, buka hasil workflow.
7. Pada bagian **Artifacts**, download:
   `WAStatusHD-Pro-v2.0-release`
8. Ekstrak artifact tersebut.
9. Install:
   `WAStatusHD-Pro-v2.0-release.apk`

APK release diberi tanda tangan otomatis oleh GitHub Actions sehingga dapat dipasang sebagai aplikasi Android biasa.

### Catatan signing
Workflow saat ini memakai signing key sementara yang dibuat saat setiap build. Artinya APK hasil build berikutnya akan memiliki kunci berbeda dan tidak dapat dipasang sebagai update di atas APK build sebelumnya; untuk update berkelanjutan, gunakan satu keystore pribadi yang disimpan sebagai GitHub Actions Secrets.
